
=readme

command example:
perl thisScript.pl hashA.txt hashB.txt

=cut

if(@ARGV!=2){
	die;
}
for$aa6(0..@ARGV-1){
	print"ARGV ",$aa6,": ",$ARGV[$aa6],"\n";
}
print"\n\n";
@f6=();
for$aa6(0..@ARGV-1){
	@{$f6[$aa6]}=();
	open F6,$ARGV[$aa6]or die$!;
	@zz6=<F6>or die$!;
	close F6 or die$!;
	print"the line number of     ",$ARGV[$aa6],"     is ",scalar(@zz6),"\n";
	foreach(@zz6){
		s/\r//g;
		if($_ eq "\n"){}else{
			push@{$f6[$aa6]},$_ or die$!;
			@ss6=split(/\t/,$_)or die$!;
			$_=$ss6[1];
			for$bb6(2..@ss6-1){
				$_.="\t".$ss6[$bb6];
			}
			$h6[$aa6]{$ss6[0]}=$_;
		}
	}
	print$ARGV[$aa6],"     has ",scalar(@{$f6[$aa6]})," items\n\n\n";
}
if(scalar(@{$f6[0]})!=scalar(@{$f6[1]})){
	print$ARGV[0],"     and     ",$ARGV[1],"     do not have the same number of items\n\n\n";
}else{
	print$ARGV[0],"     and     ",$ARGV[1],"     have the same number of items\n\n\n";
}
@c6=();
foreach(keys%{$h6[0]}){
	if(exists$h6[1]{$_}){
		push@{$c6[2]},$_;#common
	}else{
		push@{$c6[0]},$_;#ARGV0 has, while ARGV1 does not have
	}
}
foreach(keys%{$h6[1]}){
	if(exists$h6[0]{$_}){
		
	}else{
		push@{$c6[1]},$_;#ARGV1 has, while ARGV0 does not have
	}
}
print"there are ",scalar(@{$c6[2]})," in common\n",
$ARGV[0],"     has ",scalar(@{$c6[0]}),", while     ",$ARGV[1],"     does not have\n",
$ARGV[1],"     has ",scalar(@{$c6[1]}),", while     ",$ARGV[0],"     does not have\n\n\n";

$aa6=0;
foreach(@{$c6[2]}){
	if($h6[0]{$_}eq$h6[1]{$_}){
		
	}else{
		$aa6++;
		print$_,"     not same hash:     ",
		$ARGV[0]," : ",$h6[0]{$_},
		"ne/!=     ",$ARGV[0]," : ",$h6[0]{$_};
	}
}
print"for those in common, there are ",$aa6," items that do not have the same hash\n\n\n",
"done\n";
