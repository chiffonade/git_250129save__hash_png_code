


=readme

perl this_script.pl

注意所有文件（夹）名称都不包含要转义的字符


=cut


$vperl=    'PERL      ';
$vshell=   'SHELL     ';
$vreadpipe='READPIPE  ';
sub sperl{
	if(@_!=1){
		die;
	}
	print$vperl.$_[0]."\n"or die$!;
}
sub sshell{
	if(@_!=1){
		die;
	}
	print$vshell.$_[0]."\n"or die$!;
	!system$_[0]or die$!;
}
sub sreadpipe{
	if(@_!=1){
		die;
	}
	print$vreadpipe.$_[0]."\n"or die$!;
	$vsub=readpipe$_[0]or die$!;
	return$vsub;
}
sub sbackslash{
	if(@_!=1){
		die;
	}
	$vsub=$_[0];
	$vsub=~s/ /\\ /g;
	$vsub=~s/\(/\\\(/g;
	$vsub=~s/\)/\\\)/g;
	$vsub=~s/\[/\\\[/g;
	$vsub=~s/\]/\\\]/g;
	$vsub=~s/\'/\\\'/g;
	$vsub=~s/\&/\\\&/g;#2012172040added
	$vsub=~s/\;/\\\;/g;#210402added
	$vsub=~s/\$/\\\$/g;#210820added
	$vsub=~s/\"/\\\"/g;
	$vsub=~s/\~/\\\~/g;
	$vsub=~s/\#/\\\#/g;
	$vsub=~s/\!/\\\!/g; # 220525 新增
	$vsub=~s/\./\\\./g;
	return$vsub;
}
sub swhilesystem{
	if(@_!=1){
		die;
	}
	$vsub=$vsaa=1;
	while($vsub!=0){
		sperl('WHILESYSTEM  第'.$vsaa.'次尝试： '.$_[0]);
		$vsaa++;
		$vsub=system$_[0];
		if($vsaa==11 and $vsub!=0){
			die$_[0].'已被swhilesystem尝试11次，不得不报错';
		}
	}
}


sperl('暂停9999秒');
sleep 9999;
$_=sreadpipe('ls');
@a=split;
foreach(@a){
	if(m/^\d+\.png$/){}else{
		die$_;
	}
}
$d=0;
$dlim=10**5+1;
foreach(@a){
	$d++;
	if($d<$dlim){
		sshell('mv '.$_.' ~/b.xxd')
	}else{
		last;
	}
}


sperl('done.');
