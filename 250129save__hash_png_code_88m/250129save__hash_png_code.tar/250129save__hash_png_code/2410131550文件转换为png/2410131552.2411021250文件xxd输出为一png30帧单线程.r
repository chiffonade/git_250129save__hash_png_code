
scomment= r'--[
本脚本生成720pPNG图片，即为1280*720。每个像素表示0（黑）或1（白）。
所以每次能接收的0或1字数不能超过1280*720，也就是921600个。
如果生成youtube的12小时视频，那就是1280*720（像素）/8（八位一字节）*1（一秒30帧，一张图播放30帧）*3600*12，
也就是4976640000字节，大约4.6GB。
同时xxd是1280*720（像素）/48（xxd一行6字节，每字节8位）*2*3600*12，也就是1658880000行
一张png图像可储存1280*720/8，即115200字节的数据
所以最多生成4976640000/115200，即43200个png，请确保拥有足够存储空间

输出png: Rscript this_script.r some.file
这会在当前目录输出png
接下来就可以使用指令转换为视频：
ffmpeg -framerate 30 -pattern_type glob -i "*.png" -vf format=gray -c:v libx264 -b:v 9999k ~/output.mp4

xxd -b 某文件的输出例子：
00001644: 00100100 00100001 00111011 00001101 00001010 01110000  $!;..p
0000164a: 01110010 01101001 01101110 01110100 00100010 01100100  rint"d
00001650: 01101111 01101110 01100101 00101110 01011100 01101110  one.\n
00001656: 00100010 00111011 00001101 00001010                    ";..
可见，如果文件字节不是6的整倍数，则最后一行会不满八列
第一列表示位置，最后一列表示内容，中间的六列（最后一行可能不满六列）表示六个字节
每个字节八位，用八个0或1表示
]--'

setwd('.')
#library(data.table)
fchec.fun.argv <- function(cfun){
	if(length(cfun) != 1){
		stop()
	}
	if(is.character(cfun)){
		
	}else{
		stop()
	}    
}
sout= 'R语言    '
fcompare <- function(afun1, afun2){
	lfun <- F
	if(length(afun1) == length(afun2)){
		if(length(afun1) == sum(afun1 == afun2)){
			lfun <- T
		}
	}
	return(lfun)
}
fshell = function(cfun){
	fchec.fun.argv(cfun)
	cexit <- system(
		cfun, intern = T
	)
	if(is.null(attr(cexit, 'status')) ){ # 运行成功一般为NULL
		ccomment <- 'do nothing'
	}else{
		if(attr(cexit, 'status') !=0){
			stop()
		}else{
			stop()
		}
	}
	return(cexit)
}
fcheck.pos.int =function(cfun, cfun2){
	if(grepl("^[1-9][0-9]*$", cfun)){ scomment='do nothing' }else{ #检查cfun是否为正整数
		flog(
			c(sout, cfun2, '：', cfun) #cfun2作为报错提示
		)
		stop()
	}
}
if(F){
	rm(list=ls()) ; gc()
}


sarg<- commandArgs(trailingOnly = TRUE)
if (length(sarg)!= 1) {
	stop(sout, '参数数量不对')
}
if(sarg[1] !='2png'){ scomment='do nothing' }else{
	stop(sout, '参数不对', sarg[1])
}


library(png)


message(
	sout, '现将检查目标文件大小是否相符'
)
s<- system(paste0('ls -l ', sarg[1]), intern = TRUE)
i= as.numeric(strsplit(s, '\\s+')[[1]][5] ) #用ls -l获取文件字节数
if(i> 4900000000){ #4976640000是12小时、720p、每秒1张图的视频，能储存的文件字节数上限。youtube最长可上传12小时视频
	stop(sout, '目标文件', sarg[1], '太大：', i, '字节')
}
itotal.png= ceiling(i/ 115200)
message(
	sout, '目标文件', sarg[1], '大小为：', i, '字节\n', '将产生', itotal.png, '个png'
)


fhandle<- pipe(
	paste0(
		"xxd -b ", sarg[1], 
		r"[ | cut -d" " -f2-7 | tr -d " " | tr -d "\t" | tr -d "\r" ]"
	),
	"r"
)


aconst =  array(0.5, dim = c(720, 1280, 3)) #新建三维（红、绿、蓝）阵列，表示全灰的png
mconst =aconst[,,1]
i= 1
while(T){
	#message(i)
	sline= readLines(fhandle, n= 19200) # 一次最多读19200线程数的行的xxd，一行xxd六字节，那就是115200字节
	ilen= length(sline)
	if(ilen== 0){# 读不到东西，说明已经到末尾，退出循环
		break
	}
	
	
	if(i> 1){
		if(length(sprev)!= 19200){
			stop('aprev')
		}
	}
	sprev= sline
	
	
	
	abin= as.numeric(
		unlist( #转换为0101数字向量，一位数字一个元素
			strsplit(sline, '')
		)
	)
	if( length(abin)> 921600 ){ #即115200*8，也是720*1280
		stop(sout, 'abin元素数大于102240')
	}
	if( #这个向量应该只有01
		unique(
			unique(abin)%in% c(0,1)
		) !=T
	){
		stop(sout, 'there are element other than 0,1 in abin')
	}
	
	
	a =aconst
	m= mconst
	m[1:length(abin)]= abin #将0.5替换为上述向量的0或1
	a[,,1]= a[,,2]= a[,,3]= m
	
	
	c= paste0(
		paste0( rep('0', 6- nchar(i)), collapse = '' ), i, '.',
		collapse = ''
	)
	cpng =paste0(c, '00.png')
	png::writePNG(
		a,
		target= cpng
	)
	message(sout, '生成了', cpng)
	
	
	for(i2nd.field in 1:29){
		c2nd.field =paste0(
			paste0( rep('0', 2- nchar(i2nd.field)), collapse = '' ), i2nd.field, 
			collapse = ''
		)
		cln =paste0(
			'ln -s ', cpng, ' ', 
			paste0(
				c, c2nd.field, '.png'
			)
		)
		message(sout, cln)
		fshell(cln)
	}
	
	
	i= i+1
}
close(fhandle)
vls =fshell('ls')
if(length(vls)!=30*itotal.png){
	stop('length(vls)!=30*itotal.png')
}


message(sout, 'done.')