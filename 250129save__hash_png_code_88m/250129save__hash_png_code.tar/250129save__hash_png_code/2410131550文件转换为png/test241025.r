
scomment= r'--[
输出png: Rscript this_script.r 2png some.file
这会在当前目录输出png
接下来就可以使用指令转换为视频：
ffmpeg -framerate 24 -pattern_type glob -i "*.png" -vf format=gray -c:v libx264 -b:v 4444k ~/output.mp4

从png解码为文件： ffmpeg -i ~/output.mp4 -vf "format=gray" -threads 1 %07d.png
Rscript this_script.r 2file 3494903808 | tr -d '[:space:]' | fold -w8 | xxd -r -b > some.file
这会读取当前目录中ffmpeg生成的png，解码生成some.file
第2个参数是源文件的字节数

xxd -b 某文件的输出例子：
00001644: 00100100 00100001 00111011 00001101 00001010 01110000  $!;..p
0000164a: 01110010 01101001 01101110 01110100 00100010 01100100  rint"d
00001650: 01101111 01101110 01100101 00101110 01011100 01101110  one.\n
00001656: 00100010 00111011 00001101 00001010                    ";..
可见，如果文件字节不是6的整倍数，则最后一行会不满八列
第一列表示位置，最后一列表示内容，中间的六列（最后一行可能不满六列）表示六个字节
每个字节八位，用八个0或1表示
]--'

setwd('.')
#library(data.table)
fchec.fun.argv <- function(cfun){
	if(length(cfun) != 1){
		stop()
	}
	if(is.character(cfun)){
		
	}else{
		stop()
	}    
}
sout= 'R语言    '
fcompare <- function(afun1, afun2){
	lfun <- F
	if(length(afun1) == length(afun2)){
		if(length(afun1) == sum(afun1 == afun2)){
			lfun <- T
		}
	}
	return(lfun)
}
fshell = function(cfun){
	fchec.fun.argv(cfun)
	cexit <- system(
		cfun, intern = T
	)
	if(is.null(attr(cexit, 'status')) ){ # 运行成功一般为NULL
		ccomment <- 'do nothing'
	}else{
		if(attr(cexit, 'status') !=0){
			stop()
		}else{
			stop()
		}
	}
	return(cexit)
}
fcheck.pos.int =function(cfun, cfun2){
	if(grepl("^[1-9][0-9]*$", cfun)){ scomment='do nothing' }else{ #检查cfun是否为正整数
		flog(
			c(sout, cfun2, '：', cfun) #cfun2作为报错提示
		)
		stop()
	}
}
if(F){
	rm(list=ls()) ; gc()
}


sarg<- commandArgs(trailingOnly = TRUE)
i= length(sarg)
if (i!= 2) {
	stop(sout, '参数数量不对')
}
if(sarg[1] %in% c('2png', '2file')){ scomment='do nothing' }else{
	stop(sout, '第一个参数不对', sarg[1])
}


library(png)
library(parallel)


f2png= function(lfun){
	scomment= '
lfun是一个list
lfun[[1]]是一个字符串array，最多2130个元素，即2130行xxd输出的0、1
lfun[[2]]是一个字符串，是即将生成的png的文件名
	'
	message(sout)
	a =  array(0.5, dim = c(720, 1280, 3)) #新建三维（红、绿、蓝）阵列，表示全灰的png
	abin= as.numeric(
		unlist( #转换为0101数字向量，一位数字一个元素
			strsplit(lfun[[1]], '')
		)
	)
	if( length(abin)> 102240 ){
		stop(sout, 'abin元素数大于102240')
	}
	if( #这个向量应该只有01
		unique(
			unique(abin)%in% c(0,1)
		) !=T
	){
		stop(sout, 'there are element other than 0,1 in abin')
	}
	
	
	m= matrix( #新建一个矩阵，对应上述1278*720/9个0或1数字
		rep(0.5, 1278*720/3/3), nrow = 720/3, ncol = 1278/3
	)
	m[1:length(abin)]= abin #将0.5替换为上述向量的0或1
	a[,1:1278,1]= a[,1:1278,2]= a[,1:1278,3]= m[rep(1:nrow(m), each = 3), rep(1:ncol(m), each = 3)]
	#将m扩大3倍，从一个矩阵元素变为9个矩阵元素的九宫格，然后替换输出矩阵的对应位置
	
	
	png::writePNG(
		a,
		target= paste0(lfun[[2]], '.1.png')
	)
	abin= paste0( #新建两个软链接
		'ln -s ', paste0(lfun[[2]], '.1.png'), ' ', paste0(lfun[[2]], '.2.png'),
		' ; ',
		'ln -s ', paste0(lfun[[2]], '.1.png'), ' ', paste0(lfun[[2]], '.3.png')
	)
	message(sout, abin)
	if( system(abin)== 0){ scomment='do nothing' }else{
		stop(sout, 'shell失败：', abin)
	}
	message(sout, '生成了', lfun[[2]])
	
	
	return(0)
}


if(sarg[1]== '2png'){
	message(
		sout, 
		'本脚本生成720pPNG图片，实质涉及像素为1278*720。用3*3也就是9个像素的色块表示0（黑）或1（白）。',
		'所以每次能接收的0或1字数不能超过1278*720/9，也就是102240个。

如果生成youtube的11小时视频，那就是1278 *720 /9（像素）/8（八位一字节）*8（一秒24帧，一张图播放三帧）*3600*11，
也就是4048704000字节，大约3.8GB。\n\n',
		'同时xxd是1278*720/9（像素）/48（xxd一行6字节，每字节8位）*8*3600*11，也就是674784000行\n\n',
		'一张png图像可储存1278*720/9/8，即12780字节的数据\n',
		'所以最多生成4048704000/12780，即316800个png，请确保拥有足够存储空间\n\n',
		'现将检查目标文件大小是否相符'
	)
	s<- system(paste0('ls -l ', sarg[2]), intern = TRUE)
	i= as.numeric(strsplit(s, '\\s+')[[1]][5] ) #用ls -l获取文件字节数
	if(i> 4416000000){ #4416768000是12小时、720p、每秒8张图的视频，能储存的文件字节数上限。youtube最长可上传12小时视频
		stop(sout, '目标文件', sarg[2], '太大：', i, '字节')
	}
	ipng= ceiling(i/ 12780)
	message(
		sout, '目标文件', sarg[2], '大小为：', i, '字节\n', '将产生', ipng, '个png'
	)
	
	
	cat(
		sout, '请输入任意正整数，以确认运行本脚本。输入的正整数将会作为本脚本运行的线程数：',
		sep= ''
	)
	im= readLines(con = "stdin", n = 1)
	if(grepl("^[1-9][0-9]*$", im)){ scomment='do nothing' }else{
		stop(sout, '第二个参数不是大于等于1的整数：', sarg[2])
	}
	im= as.numeric(im)
	if(im>= parallel::detectCores()){
		stop(sout, '您输入的线程数：', im, '，大于等于系统处理器线程上限：', parallel::detectCores())
	}
	
	
	fhandle<- pipe(
		paste0(
			"xxd -b ", sarg[2], 
			r"[ | cut -d" " -f2-7 | tr -d " " | tr -d "\t" | tr -d "\r" ]"
		),
		"r"
	)
	i= 1
	while(T){
		#message(i)
		sline= readLines(fhandle, n= 2130* im) # 一次最多读2130*线程数的行的xxd，一行xxd六字节，那就是12780*im字节
		ilen= length(sline)
		if(ilen== 0){# 读不到东西，说明已经到末尾，退出循环
			break
		}
		
		
		if(i> 1){
			if(length(sprev)!= 2130* im){
				stop('aprev')
			}
		}
		sprev= sline
		
		
		isimul= ceiling(ilen/ 2130) #真正的并发数，因为读到最后的时候，可能少于2130*im行
		
		
		lxxd.png= list()
		for(i2 in 1:isimul){
			lxxd.png[[i2]]= list()
			if(i2== isimul){
				lxxd.png[[i2]][[1]]= sline[((i2-1)*2130+1):ilen]
			}else{
				lxxd.png[[i2]][[1]]= sline[((i2-1)*2130+1):((i2-1)*2130+2130)]
			}
			if(NA %in% lxxd.png[[i2]][[1]]){
				stop('NA')
			}
			ipng= i+i2-1
			lxxd.png[[i2]][[2]]= paste0(
				paste0( rep('0', 6- nchar(ipng)), collapse = '' ), ipng, #'.1.png',
				collapse = ''
			) # 6-nchar是因为最多316800，也就是六位数个png
		}
		
		
		l=parallel::mclapply(
			lxxd.png, f2png, mc.cores = isimul
		)
		if(length(l)!=isimul){
			stop('result len')
		}
		for(i2 in 1:isimul){
			if(l[[i2]]!=0){
				stop('result l i2：', l[[i2]])
			}
		}
		i= i+ isimul
	}
	close(fhandle)
}




if(sarg[1]== '2file'){
	flog =function(afun){
		file_conn <- file("~/2410131553.log", open = "a")
		writeLines(
			paste0(afun, collapse = ''), file_conn
		)
		close(file_conn)
	}
	
	
	flog(rep('\n',9)) #在日志文件换行九次，以与之前的执行日志隔开
	fcheck.pos.int(sarg[2], '第2个参数，正整数')
	
	
	ibyte =as.numeric(sarg[2])
	iframe =as.numeric(ceiling(ibyte*8 /(1278*720/9)) *3)
	if(iframe %%3 !=0){
		flog(c(sout, 'png数量不是3的整倍数：', iframe))
		stop()
	}
	ilast.frame.bit.lenth = (ibyte*8) %% (1278*720/9)
	flog(c(
		'源文件有',as.character(ibyte),'字节。',
		'经计算视频应有',as.character(iframe),'帧。',
		'最后一帧应储存',as.character(ilast.frame.bit.lenth),'位0或1数字'
	))
	
	
	fpng2bin =function(lfun){
		flog(c(sout, lfun[[2]]))
		m =png::readPNG(lfun[[2]]) #灰度的png，m只有一层矩阵
		if(
			fcompare(dim(m), c(720,1280))
		){ scomment='do nothing' }else{
			flog(c(sout, '图片大小不对'))
		}
		
		
		lrow=lcol=list()
		lrow[[1]]=(1:(720/3))*3
		lrow[[2]]=lrow[[1]]-1
		lrow[[3]]=lrow[[1]]-2
		lcol[[1]]=(1:(1278/3))*3
		lcol[[2]]=lcol[[1]]-1
		lcol[[3]]=lcol[[1]]-2
		
		
		v=as.vector((
			m[lrow[[1]],lcol[[1]]]+ m[lrow[[1]],lcol[[2]]]+ m[lrow[[1]],lcol[[3]]]+ 
				m[lrow[[2]],lcol[[1]]]+ m[lrow[[2]],lcol[[2]]]+ m[lrow[[2]],lcol[[3]]]+  
				m[lrow[[3]],lcol[[1]]]+ m[lrow[[3]],lcol[[2]]]+ m[lrow[[3]],lcol[[3]]]
		)/9)
		if(lfun[[1]]>lfun[[3]]-3){
			v =v[1:lfun[[4]]]
		}else{
			if(length(v)!=1278*720/9){
				flog(c(sout, 'v元素数不对'))
			}
		}
		
		
		vwblack =which(v <0.4)
		vwwhite =which(v >0.6)
		vu =sort(union(vwblack, vwwhite) )
		if(fcompare(vu, 1:length(v))){ scomment='do nothing' }else{ #应该全为黑或白
			flog(c(sout, lfun[[2]], '有灰'))
			stop()
		}
		vclean =v
		vclean[vwblack] =rep(0, length(vwblack))
		vclean[vwwhite] =rep(1, length(vwwhite))
		v01 =vclean[which(vclean==1|vclean==0)]
		if(length(v01) ==length(v)){ scomment='do nothing' }else{
			flog(c(sout, lfun[[2]], 'v01有灰'))
			stop()
		}
		
		
		return(
			paste0(v01, collapse = '')
		)
	}
	
	
	isleep =1
	while(T){
		als= fshell('ls') #获取目前目录所有png文件名
		if(length(als)==0){
			flog(c(
				'当前目录还没png，暂停一会，这是第',isleep,'次暂停'
			))
			fshell('sleep 4')
			isleep =isleep +1
			next
		}
		if(
			length(
				unique(nchar(als))
			) !=1
		){
			flog(c(sout, '有文件名字符个数与众不同'))
			stop()
		}
		if(F %in% grepl('.png$', als)){
			flog(c(sout, '存在非png'))
			stop()
		}
		
		
		v =as.numeric( #将目前目录里png文件名转为数字
			unlist(
				strsplit(als, '.png')
			)
		)
		ilen =length(v)
		if(v[ilen] >iframe){ #最后一个png的数字不可能大于总帧数
			flog(c(sout, 'v[ilen'))
			stop()
		}
		if(v[1]%%3 !=1){
			flog(c(sout,'第一个png的数字不是1、4、7..'))
			stop()
		}
		
		
		if(v[ilen] ==iframe | ilen >4){
			#如果最后一个png就是最后一帧了，或者，最后一个png在当前要处理的最后一个png之后，就开始处理并删去png
			if(v[ilen] ==iframe){
				if(ilen%%3 !=0){
					flog(c(sout,'ilen%%3 !=0'))
					stop()
				}
				if(ilen ==3){
					fshell('sleep 4')
				}
			}
			
			
			l =list() #l是两层list，储存并行处理的函数的元素。l[[i3]][[1]]储存了要处理的png文件名（去除后缀、转为数字）
			#l[[i3]][[2]]储存了总帧数
			for(i2 in 1:3){
				l[[i2]] =list(
					v[i2], als[i2], iframe, ilast.frame.bit.lenth
				) #png数字，png文件名，总帧数，最后一帧的0或1位数
			}
			
			
			lreturn =parallel::mclapply( #并行计算
				l, fpng2bin, mc.cores = 3
			)
			if(length(lreturn) !=3){
				flog(c(sout, 'result len lreturn 3'))
				stop()
			}
			iu =unique(nchar(lreturn))
			if( length(iu)!=1){
				flog(c(sout, 'lreturn 3 string不一样长'))
				stop()
			}
			if(iu ==1278*720/9){ scomment='do nothing' }else{ #不然就也是到了最后
				if(v[ilen] ==iframe){ scomment='do nothing' }else{
					flog(c(sout, '没到最后已不足全屏幕应有长度'))
					stop()
				}
				if(iu >1278*720/9){
					flog(c(sout, 'iu >1278*720/9'))
					stop()
				}
			}
			if(
				length(
					unique(unlist(lreturn))
				) !=1
			){
				flog(c(sout, 'lreturn3元素不同'))
			}
			cat(
				lreturn[[1]]
			) 
			
			
			c =paste('rm',l[[1]][[2]],l[[2]][[2]],l[[3]][[2]])
			flog(c)
			fshell(c) #删除当前png，及前后png
			
			
			if(v[ilen] ==iframe & ilen ==3){
				break
			}
			
		}
		
		
	}
}



message(sout, 'done.')