
scomment= r'--[

]--'

setwd('.')
#library(data.table)
fchec.fun.argv <- function(cfun){
	if(length(cfun) != 1){
		stop()
	}
	if(is.character(cfun)){
		
	}else{
		stop()
	}    
}
sout= 'R语言    '
fcompare <- function(afun1, afun2){
	lfun <- F
	if(length(afun1) == length(afun2)){
		if(length(afun1) == sum(afun1 == afun2)){
			lfun <- T
		}
	}
	return(lfun)
}
fshell = function(cfun){
	fchec.fun.argv(cfun)
	cexit <- system(
		cfun, intern = T
	)
	if(is.null(attr(cexit, 'status')) ){ # 运行成功一般为NULL
		ccomment <- 'do nothing'
	}else{
		if(attr(cexit, 'status') !=0){
			stop()
		}else{
			stop()
		}
	}
	return(cexit)
}
fcheck.pos.int =function(cfun, cfun2){
	if(grepl("^[1-9][0-9]*$", cfun)){ scomment='do nothing' }else{ #检查cfun是否为正整数
		flog(
			c(sout, cfun2, '：', cfun) #cfun2作为报错提示
		)
		stop()
	}
}
if(F){
	rm(list=ls()) ; gc()
}


library(png)


vls =fshell('ls')
if(length(vls)%%15!=0){
	stop(sout, 'len vls整除15')
}
ilen =length(vls)-15
v =rep(0.5, 15)
vpng =rep(NA, 15)
ipixel =720 *1280
for(i in 1:ilen){
	if(i%%10==0){
		message(sout, vls[i])
	}
	m =png::readPNG(vls[i])
	if(fcompare(dim(m), c(720, 1280))){
		scomment ='do nothing'
	}else{
		stop(sout, '维数不对')
	}
	iindex =i%%15
	if(iindex ==0){
		iindex =15
	}
	id =min(
		abs(
			as.vector(m) -rep(0.5, ipixel)
		)
	)
	if(v[iindex] >id){
		v[iindex] =id
		vpng[iindex] =vls[i]
	}
}
message(
	sout, paste(v, collapse = '\n')
)


message(sout, 'done.')