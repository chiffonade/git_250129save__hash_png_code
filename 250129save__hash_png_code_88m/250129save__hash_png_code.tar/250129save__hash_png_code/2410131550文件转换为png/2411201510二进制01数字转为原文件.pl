


=readme

perl this_script.pl

注意所有文件（夹）名称都不包含要转义的字符


=cut


$vperl=    'PERL      ';
$vshell=   'SHELL     ';
$vreadpipe='READPIPE  ';
sub sperl{
	if(@_!=1){
		die;
	}
	print$vperl.$_[0]."\n"or die$!;
}
sub sshell{
	if(@_!=1){
		die;
	}
	print$vshell.$_[0]."\n"or die$!;
	!system$_[0]or die$!;
}
sub sreadpipe{
	if(@_!=1){
		die;
	}
	print$vreadpipe.$_[0]."\n"or die$!;
	$vsub=readpipe$_[0]or die$!;
	return$vsub;
}
sub sbackslash{
	if(@_!=1){
		die;
	}
	$vsub=$_[0];
	$vsub=~s/ /\\ /g;
	$vsub=~s/\(/\\\(/g;
	$vsub=~s/\)/\\\)/g;
	$vsub=~s/\[/\\\[/g;
	$vsub=~s/\]/\\\]/g;
	$vsub=~s/\'/\\\'/g;
	$vsub=~s/\&/\\\&/g;#2012172040added
	$vsub=~s/\;/\\\;/g;#210402added
	$vsub=~s/\$/\\\$/g;#210820added
	$vsub=~s/\"/\\\"/g;
	$vsub=~s/\~/\\\~/g;
	$vsub=~s/\#/\\\#/g;
	$vsub=~s/\!/\\\!/g; # 220525 新增
	$vsub=~s/\./\\\./g;
	return$vsub;
}
sub swhilesystem{
	if(@_!=1){
		die;
	}
	$vsub=$vsaa=1;
	while($vsub!=0){
		sperl('WHILESYSTEM  第'.$vsaa.'次尝试： '.$_[0]);
		$vsaa++;
		$vsub=system$_[0];
		if($vsaa==11 and $vsub!=0){
			die$_[0].'已被swhilesystem尝试11次，不得不报错';
		}
	}
}


$snote='请确保第一个参数（二进制01数字txt文件）、第二个参数（输出文件）'.
'文件名及其路径，不包含任何涉及转义的字符，否则本脚本将会出错！';
sperl($snote);
sleep 4;
if(@ARGV==2){}else{
	die;
}
open(Hin, "<", $ARGV[0]) or die$!;
open(Hout, ">:raw", $ARGV[1]) or die$!;
while (<Hin>) {
	s/\n$//;
	s/\r$//;
	s/\n$//;
	if(m/^[01]+$/){}else{
		die'there is char other than 0 or 1';
	}
	if((length($_)%8)== 0){}else{
		die'not multiple of 8'
	}
    @abytes = (m/(.{8})/g);
    # Convert each 8-bit binary string back to a byte and write to the binary file
    print Hout pack("C*", map { oct("0b$_") } @abytes);
}
close(Hin)or die$!;
close(Hout)or die$!;


sperl($snote);
sperl('done.');
