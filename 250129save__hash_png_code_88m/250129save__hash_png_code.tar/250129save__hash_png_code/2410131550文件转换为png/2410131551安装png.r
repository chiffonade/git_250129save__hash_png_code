
setwd('.')
#library(data.table)
fchec.fun.argv <- function(cfun){
	if(length(cfun) != 1){
		stop()
	}
	if(is.character(cfun)){
		
	}else{
		stop()
	}    
}
fprint <- function(cfun){
	fchec.fun.argv(cfun)
	message(
		paste0('R语言     ', cfun)
	)
}
fcompare <- function(afun1, afun2){
	lfun <- F
	if(length(afun1) == length(afun2)){
		if(length(afun1) == sum(afun1 == afun2)){
			lfun <- T
		}
	}
	return(lfun)
}
fshell = function(cfun){
	fchec.fun.argv(cfun)
	cexit <- system(
		cfun, intern = T
	)
	if(is.null(attr(cexit, 'status')) ){ # 运行成功一般为NULL
		ccomment <- 'do nothing'
	}else{
		if(attr(cexit, 'status') !=0){
			stop()
		}else{
			stop()
		}
	}
	return(cexit)
}

if(F){
	rm(list=ls()) ; gc()
}


install.packages('png')