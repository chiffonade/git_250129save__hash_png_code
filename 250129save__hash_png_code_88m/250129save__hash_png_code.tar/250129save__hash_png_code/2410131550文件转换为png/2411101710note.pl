


=readme

perl this_script.pl

注意所有文件（夹）名称都不包含要转义的字符


=cut


$vperl=    'PERL      ';
$vshell=   'SHELL     ';
$vreadpipe='READPIPE  ';
sub sperl{
	if(@_!=1){
		die;
	}
	print$vperl.$_[0]."\n"or die$!;
}
sub sshell{
	if(@_!=1){
		die;
	}
	print$vshell.$_[0]."\n"or die$!;
	!system$_[0]or die$!;
}
sub sreadpipe{
	if(@_!=1){
		die;
	}
	print$vreadpipe.$_[0]."\n"or die$!;
	$vsub=readpipe$_[0]or die$!;
	return$vsub;
}
sub sbackslash{
	if(@_!=1){
		die;
	}
	$vsub=$_[0];
	$vsub=~s/ /\\ /g;
	$vsub=~s/\(/\\\(/g;
	$vsub=~s/\)/\\\)/g;
	$vsub=~s/\[/\\\[/g;
	$vsub=~s/\]/\\\]/g;
	$vsub=~s/\'/\\\'/g;
	$vsub=~s/\&/\\\&/g;#2012172040added
	$vsub=~s/\;/\\\;/g;#210402added
	$vsub=~s/\$/\\\$/g;#210820added
	$vsub=~s/\"/\\\"/g;
	$vsub=~s/\~/\\\~/g;
	$vsub=~s/\#/\\\#/g;
	$vsub=~s/\!/\\\!/g; # 220525 新增
	$vsub=~s/\./\\\./g;
	return$vsub;
}
sub swhilesystem{
	if(@_!=1){
		die;
	}
	$vsub=$vsaa=1;
	while($vsub!=0){
		sperl('WHILESYSTEM  第'.$vsaa.'次尝试： '.$_[0]);
		$vsaa++;
		$vsub=system$_[0];
		if($vsaa==11 and $vsub!=0){
			die$_[0].'已被swhilesystem尝试11次，不得不报错';
		}
	}
}


$c='牛';
$_='油 津 奶';
foreach(split){
	$s=$c.$_;
}
foreach(0..4){
	$s='version 1.'.$_;
}
$_='退 老';
foreach(split){
	$s='衰'.$_;
	
	$s=4;
}
foreach(2000..2024){
	$s='Copyright 1999-'.$_;
}


sperl('done.');
