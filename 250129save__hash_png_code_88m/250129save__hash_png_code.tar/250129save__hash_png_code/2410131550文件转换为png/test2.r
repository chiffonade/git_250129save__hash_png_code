
scomment= 'Rscript this_script.r some.file

xxd -b 某文件的输出例子：
00001644: 00100100 00100001 00111011 00001101 00001010 01110000  $!;..p
0000164a: 01110010 01101001 01101110 01110100 00100010 01100100  rint"d
00001650: 01101111 01101110 01100101 00101110 01011100 01101110  one.\n
00001656: 00100010 00111011 00001101 00001010                    ";..
可见，如果文件字节不是6的整倍数，则最后一行会不满八列
第一列表示位置，最后一列表示内容，中间的六列（最后一行可能不满六列）表示六个字节
每个字节八位，用八个0或1表示
'

setwd('.')
#library(data.table)
fchec.fun.argv <- function(cfun){
	if(length(cfun) != 1){
		stop()
	}
	if(is.character(cfun)){
		
	}else{
		stop()
	}    
}
sout= 'R语言    '
fcompare <- function(afun1, afun2){
	lfun <- F
	if(length(afun1) == length(afun2)){
		if(length(afun1) == sum(afun1 == afun2)){
			lfun <- T
		}
	}
	return(lfun)
}
fshell = function(cfun){
	fchec.fun.argv(cfun)
	cexit <- system(
		cfun, intern = T
	)
	if(is.null(attr(cexit, 'status')) ){ # 运行成功一般为NULL
		ccomment <- 'do nothing'
	}else{
		if(attr(cexit, 'status') !=0){
			stop()
		}else{
			stop()
		}
	}
	return(cexit)
}

if(F){
	rm(list=ls()) ; gc()
}


library(png)
sarg<- commandArgs(trailingOnly = TRUE)
i= length(sarg)
if (i!= 1) {
	stop(sout, '参数数量错误：', i)
}


message(
	sout, 
	'本脚本生成720pPNG图片，实质涉及像素为1278*720。用3*3也就是9个像素的色块表示0（黑）或1（白）。',
	'所以每次能接收的0或1字数不能超过1278*720/9，也就是102240个。

如果生成youtube的11小时视频，那就是1278 *720 /9（像素）/8（八位一字节）*8（一秒24帧，一张图播放三帧）*3600*11，
也就是4048704000字节，大约3.8GB。\n\n',
	'同时xxd是1278*720/9（像素）/48（xxd一行6字节，每字节8位）*8*3600*11，也就是674784000行\n\n',
	'一张png图像可储存1278*720/9/8，即12780字节的数据\n',
	'所以最多生成4048704000/12780，即316800个png，请确保拥有足够存储空间\n\n',
	'现将检查目标文件大小是否相符'
)
s<- system(paste0('ls -l ', sarg[1]), intern = TRUE)
i= as.numeric(strsplit(s, '\\s+')[[1]][5] )
if(i> 4048704000){
	stop(sout, '目标文件', sarg[1], '太大：', i, '字节')
}
ipng= ceiling(i/ 12780)
message(
	sout, '目标文件', sarg[1], '大小为：', i, '字节\n', '将产生', ipng, '个png'
)


cat(
	sout, '请按y确认运行本脚本：',
	sep= ''
)
if(readLines(con = "stdin", n = 1)== 'y'){}else{
	stop(sout, '您未按y确认')
}


fhandle<- pipe(
	paste0("xxd -b ", sarg[1], r"[ | cut -d" " -f2-7 | tr -d " " | tr -d "\t" | tr -d "\r" ]" ),
	"r"
)
i= 0
while(T){
	i= i+ 1 ; message(i)
	sline= readLines(fhandle, n= 2130) # 一次最多读2130行xxd，一行xxd六字节，那就是12780字节
	ilen= length(sline) #; message(sline)
	if(ilen== 0){# 读不到东西，说明已经到末尾，退出循环
		break
	}
	
	a =  array(0.5, dim = c(720, 1280, 3)) #新建三维（红、绿、蓝）阵列，表示全灰的png
	abin= as.numeric(
		unlist(
			strsplit(sline, '')
		)
	)
	if( length(abin)> 102240 ){
		stop(sout, 'abin元素数大于102240')
	}
	if(
		unique(
			unique(abin)%in% c(0,1)
		) !=T
	){
		stop(sout, 'there are element other than 0,1 in abin')
	}
	
	if(i> 1){
		if(length(aprev)!= 102240){
			stop('aprev')
		}
	}
	aprev= abin
	
	m= matrix(
		rep(0.5, 1278*720/3/3), nrow = 720/3, ncol = 1278/3
	)
	m[1:length(abin)]= abin
	a[,1:1278,1]= a[,1:1278,2]= a[,1:1278,3]= m[rep(1:nrow(m), each = 3), rep(1:ncol(m), each = 3)]
	
	png::writePNG(
		a,
		target= paste0(
			paste0( rep('0', 6- nchar(i)), collapse = '' ),
			i, '.1.png',
			collapse = ''
		) # 6-nchar是因为最多316800，也就是六位数个png
	)
	
	if(i%% 10^4== 0){
		gc()
	}
	if(i%% 500^3== 0){
		message(sout, '输出了第', i, '/', ipng, '个png')
	}
}
close(fhandle)


message(sout, 'done.')