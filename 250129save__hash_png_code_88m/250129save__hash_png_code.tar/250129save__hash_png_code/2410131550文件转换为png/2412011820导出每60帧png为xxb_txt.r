
scomment= r'--[

]--'

setwd('.')
#library(data.table)
fchec.fun.argv <- function(cfun){
	if(length(cfun) != 1){
		stop()
	}
	if(is.character(cfun)){
		
	}else{
		stop()
	}    
}
sout= 'R语言    '
fcompare <- function(afun1, afun2){
	lfun <- F
	if(length(afun1) == length(afun2)){
		if(length(afun1) == sum(afun1 == afun2)){
			lfun <- T
		}
	}
	return(lfun)
}
fshell = function(cfun){
	fchec.fun.argv(cfun)
	cexit <- system(
		cfun, intern = T
	)
	if(is.null(attr(cexit, 'status')) ){ # 运行成功一般为NULL
		ccomment <- 'do nothing'
	}else{
		if(attr(cexit, 'status') !=0){
			stop()
		}else{
			stop()
		}
	}
	return(cexit)
}
fcheck.pos.int =function(cfun, cfun2){
	if(grepl("^[1-9][0-9]*$", cfun)){ scomment='do nothing' }else{ #检查cfun是否为正整数
		flog(
			c(sout, cfun2, '：', cfun) #cfun2作为报错提示
		)
		stop()
	}
}
if(F){
	rm(list=ls()) ; gc()
}


library(png)


cat(
	sout, '请输入源文件字节数：',
	sep= ''
)
ibyte= readLines(con = "stdin", n = 1)
if(grepl("^[1-9][0-9]*$", ibyte)){ scomment='do nothing' }else{
	stop(sout, '源文件字节数不是大于等于1的整数：', ibyte)
}
ibyte= as.numeric(ibyte)
ibit = ibyte * 8


imin.larger.than.0.2= ipage = 60
ipixel =720 *1280
vls =fshell('ls')
if(length(vls)%%ipage!=0){
	stop(sout, 'len vls整除', ipage)
}
if(length(vls) == ceiling(ibit/ipixel)*ipage){}else{
	stop(sout, '图片数与源文件字节数不符。图片数：', length(vls), '。ipage：', ipage)
}
ilen =length(vls)-ipage


write_con <- file('~/2412011821.txt', "w")
fpixel2list = function(i, vls, ipage, ipixel, ilen.last){
	if(i<length(vls)){
		if(ipixel!=ilen.last){
			stop('未到最后已不足')
		}
	}
	lmin.diff=l=list()
	for(i2 in (i-(ipage-1)):i){
		i3=i2-i+ ipage
		l[[i3]] =as.vector(png::readPNG(vls[i2]) )
		if(length(l[[i3]])==ipixel){}else{
			stop(sout, '维数不对')
		}
		l[[i3]] = l[[i3]][1:ilen.last]
		lmin.diff[[i3]] =min(
			abs(
				l[[i3]] -rep(0.5, ilen.last)
			)
		)
	}
	vlarger.than.0.2=which(unlist(lmin.diff)>0.2)
	i2 =length(vlarger.than.0.2)
	if(i2 <2){
		stop('小于0.2的少于两个')
	}
	scomment=r'-[ if(imin.larger.than.0.2 > i2 ){
		imin.larger.than.0.2 = i2
	} ]-'
	imin.larger.than.0.2 = i2
	i3=0
	for(i2 in vlarger.than.0.2){
		i3=i3+1
		vw=which(l[[i2]]>0.5)
		l[[i2]][vw]=rep(1,length(vw))
		vw=which(l[[i2]]<0.5)
		l[[i2]][vw]=rep(0,length(vw))
		if(i3>1){
			if(fcompare(l[[ vlarger.than.0.2[1] ]],l[[i2]])){
				message(sout, vls[i], ' ', vlarger.than.0.2[1], ' ', i2, ' TRUE')
			}else{
				stop(sout,'矩阵不同')
			}
		}
	}
	return(
		list(
			paste(l[[ vlarger.than.0.2[1] ]], collapse = ''),
			imin.larger.than.0.2
		)
	)
}


for(i in (1:(ilen/ipage))*ipage){
	scomment=r'-[ lmin.diff=l=list()
	for(i2 in (i-89):i){
		i3=i2-i+90
		l[[i3]] =as.vector(png::readPNG(vls[i2]) )
		if(length(l[[i3]])==ipixel){}else{
			stop(sout, '维数不对')
		}
		lmin.diff[[i3]] =min(
			abs(
				l[[i3]] -rep(0.5, ipixel)
			)
		)
	}
	vlarger.than.0.2=which(unlist(lmin.diff)>0.2)
	i2 =length(vlarger.than.0.2)
	if(i2 <2){
		stop('小于0.2的少于两个')
	}
	if(imin.larger.than.0.2 > i2 ){
		imin.larger.than.0.2 = i2
	}
	i3=0
	for(i2 in vlarger.than.0.2){
		i3=i3+1
		vw=which(l[[i2]]>0.5)
		l[[i2]][vw]=rep(1,length(vw))
		vw=which(l[[i2]]<0.5)
		l[[i2]][vw]=rep(0,length(vw))
		if(i3>1){
			if(fcompare(l[[ vlarger.than.0.2[1] ]],l[[i2]])){
				message(sout, vls[i], ' ', vlarger.than.0.2[1], ' ', i2, ' TRUE')
			}else{
				stop(sout,'矩阵不同')
			}
		}
	}
	
	writeLines(paste(l[[ vlarger.than.0.2[1] ]], collapse = ''), write_con) ]-'
	lreturn = fpixel2list(i, vls, ipage, ipixel, ipixel)
	writeLines(lreturn[[1]], write_con)
	imin.larger.than.0.2 = min(imin.larger.than.0.2, lreturn[[2]])
}
message(
	sout, imin.larger.than.0.2
)


ilen.last = ibit %% ipixel
i = length(vls)
scomment=r'-[ lmin.diff=l=list()
for(i2 in (i-89):i){
	i3=i2-i+90
	l[[i3]] =as.vector(png::readPNG(vls[i2]) )
	if(length(l[[i3]])==ipixel){}else{
		stop(sout, '维数不对')
	}
	l[[i3]] = l[[i3]][1:ilen.last]
	lmin.diff[[i3]] =min(
		abs(
			l[[i3]] -rep(0.5, ilen.last)
		)
	)
}
vlarger.than.0.2=which(unlist(lmin.diff)>0.2)
i2 =length(vlarger.than.0.2)
if(i2 <2){
	stop('小于0.2的少于两个')
}
if(imin.larger.than.0.2 > i2 ){
	imin.larger.than.0.2 = i2
}
i3=0
for(i2 in vlarger.than.0.2){
	i3=i3+1
	vw=which(l[[i2]]>0.5)
	l[[i2]][vw]=rep(1,length(vw))
	vw=which(l[[i2]]<0.5)
	l[[i2]][vw]=rep(0,length(vw))
	if(i3>1){
		if(fcompare(l[[ vlarger.than.0.2[1] ]],l[[i2]])){
			message(sout, vls[i], ' ', vlarger.than.0.2[1], ' ', i2, ' TRUE')
		}else{
			stop(sout,'矩阵不同')
		}
	}
}
writeLines(paste(l[[ vlarger.than.0.2[1] ]], collapse = ''), write_con) ]-'
lreturn = fpixel2list(i, vls, ipage, ipixel, ilen.last)
writeLines(lreturn[[1]], write_con)
imin.larger.than.0.2 = min(imin.larger.than.0.2, lreturn[[2]])
message(
	sout, imin.larger.than.0.2
)


close(write_con)
message(sout, 'done.')