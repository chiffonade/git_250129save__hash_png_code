
=readme 201125from A:\8470p\20-21-1研二上\2011151720singleFileHash.pl; 201115from A:\8470p\20-21-1研二上\2009121930hashCygwin.pl
201122 no matter cygwin or linux

201115经过测试，+、#不用\

command example:
perl thisScript.pl target.file1 target.file2 targetDirectory targ*.file (..) hashOutput.txt

output example:
text#.txt	md5	677c974ef7bf26af708558f25a8d5038	sha1	142f50958b0c923ddf00bdbf591051a93a5a0930	sha256	9cecc034b502b95577d7552b78c6d929fec77a9af0449242949fd061c21f3510



=cut

#201125 commented if(@ARGV!=2){
#	die;
#}

#@g2=@l2=();#GLob
#
#for$aa2(0..@ARGV-2){
#	print"ARGV ",$aa2,": ",$ARGV[$aa2];
#	if($ARGV[$aa2]=~m/\\/){
#		die;
#	}
#	if($ARGV[$aa2]=~m/\*/){
#		print"     glob is needed for this";
#		push@g2,$ARGV[$aa2];
#		#if($aa2==@ARGV-1){
#		#	die;
#		#}
#	}else{
#		push@n2,$ARGV[$aa2];#Not need glob
#		$nn2{$ARGV[$aa2]}=1;#Not Need glob
#	}
#	print"\n";
#}
#
#print"there are ",scalar(@g2)," item(s) that need(s) glob\n\n";
#if(@g2>0){
#	for$aa2(0..@g2-1){
#		print"##### glob result(s) of [item ",($aa2+1)," : ".$g2[$aa2]."] is the following .. :\n";
#		@glob2=glob$g2[$aa2]or die$!;
#		#glob会返回包括文件夹在内的所有符合条件的东西
#		#如果文件或文件夹名称带空格等，不会也带有\
#		$_="";
#		for$bb2(0..@glob2-1){
#			$_.=$glob2[$bb2]."\n";
#			if(exists$nn2{$glob2[$bb2]}){
#				$r2.=$glob2[$bb2]." from [item ".($aa2+1)." : ".$g2[$aa2]."] is repetitive, will be omitted\n";#Repetitive
#			}
#			$nn2{$glob2[$bb2]}=1;
#		}
#		print$_,"##### glob result(s) of [item ",($aa2+1)," : ".$g2[$aa2]."] is the above\n\n";
#		push@l2,@glob2;
#	}
#}
#print$r2,"\n";
#
#print"##### after glob, there are .. :\n";
#%nn2=@a2=();#After glob
#foreach(@n2,@l2){
#	if(exists$nn2{$_} or m/desktop\.ini$/i or m/Thumbs.db$/i){
#		die;
#	}else{
#		push@a2,$_ or die$!;
#		$nn2{$_}=1;
#	}
#}
#for$aa2(0..@a2){
#	$_.=$a2[$aa2]."\n";
#}
#print$_,"##### after glob, there are (above)\n\n";





$bb2=@ARGV-1;
%nn2=();
for$aa2(0..$bb2){
	print"ARGV ",$aa2,": ",$ARGV[$aa2];
	if($aa2<$bb2){
		if(exists$nn2{$ARGV[$aa2]}){
			print"     this one is repetitive, will be omitted";
		}else{
			push@a2,$ARGV[$aa2]or die$!;
			$nn2{$ARGV[$aa2]}=1;
		}
	}else{
		print"     this one will be the output file";
	}
	print"\n";
}
print"\n";

if(-e($ARGV[@ARGV-1])){
	print"the output file: ",$ARGV[@ARGV-1],"  exists\n\n\n";
	if(-z($ARGV[@ARGV-1])){
		print"the output file: ",$ARGV[@ARGV-1],"  is empty\n\n\n";
	}else{
		print"the output file: ",$ARGV[@ARGV-1],"  seems not to be an empty file\n",
		"are you really sure you wish to continue?\n",
		"if you are, please input \"yes\", and then hit ENTER\n> ";
		$_=<stdin>;
		s/\n//g;
		s/\r//g;
		if($_ eq"yes"){
			print"\nproceed .. \n\n\n";
		}else{
			die;
		}
	}
}else{
	print"the output file: ",$ARGV[@ARGV-1],"  does not exist\n\n\n";
}


print"start find for directory..\n";
@l2=();
$bb2=0;
for$aa2(0..@a2-1){
	$a2[$aa2]=~s/\/$// ;#210516added
	push@l2,$a2[$aa2]or die$!;
	if(-d($a2[$aa2])){
		$bb2++;
		print$a2[$aa2]," is a directory\n";
		#$nn2{$a2[$aa2]}="\tdirectory\tdirectory\tdirectory\tdirectory\tdirectory\tdirectory\n\n";
		$_=$a2[$aa2];
		s/ /\\ /g;
		s/\(/\\\(/g;
		s/\)/\\\)/g;
		s/\[/\\\[/g;
		s/\]/\\\]/g;
		s/\'/\\\'/g;
		s/\&/\\\&/g;#2012172040added
		s/\;/\\\;/g;#210402added
		s/\$/\\\$/g;#210820added
		s/\"/\\\"/g;
		s/\~/\\\~/g;
		s/\#/\\\#/g;
		$o2="find ".$_." -iname \"*\"";
		print$o2,"\n"or die$!;
		$r2=readpipe$o2 or die$!;
		if($r2=~m/\r/){
			die;
		}
		@g2=split(/\n/,$r2);
		foreach(@g2){
			if(m/\n/ || m/\r/){
				die;
			}
		}
		push@l2,@g2[1..@g2-1]or die$!;
	}
}
if($bb2==0){
	print"there are no diretory that needs find\n"
}
print"\n##### after find, there are .. :\n";
$_="";
for$aa2(0..@l2){
	$_.=$l2[$aa2]."\n";
}
print$_,"##### after find, there are (above)\n\n",
"totally, there are ",scalar(@l2)," items\n\n\n";

#201204added
@g2=@l2;
@l2=@neglect2=();
for$aa2(0..@g2-1){
	$_=$g2[$aa2];
	if(m/^desktop\.ini$/i || m/\/desktop\.ini$/i || m/^Thumbs\.db$/i || m/\/Thumbs.db$/i){
		push@neglect2,$g2[$aa2]or die$!;
	}else{
		push@l2,$g2[$aa2]or die$!;
	}
}
print"there are ",scalar(@neglect2)," item(s) that will be omitted:\n",
join("\n",@neglect2),"\n",
"start hashing ..\n\n\n";

@s2=qw(md5 sha1 sha256);
open F2,">>".$ARGV[@ARGV-1]or die$!;
for$aa2(0..@l2-1){
	if(-d($l2[$aa2])){
		#$nn2{$l2[$aa2]}="\tdirectory\tdirectory\tdirectory\tdirectory\tdirectory\tdirectory\n\n";
		print$l2[$aa2],"     is a directory (",($aa2+1),"/",scalar(@l2),")\n";
		print F2 $l2[$aa2],"\tdirectory\tdirectory\tdirectory\tdirectory\tdirectory\tdirectory\n\n"or die$!;
	}else{
		#$nn2{$l2[$aa2]}="";
		print F2 $l2[$aa2]or die$!;
		for$bb2(0..@s2-1){
			$_=$l2[$aa2];
			s/ /\\ /g;
			s/\(/\\\(/g;
			s/\)/\\\)/g;
			s/\[/\\\[/g;
			s/\]/\\\]/g;
			s/\'/\\\'/g;
			s/\&/\\\&/g;#2012172040added
			s/\;/\\\;/g;#210402added
			s/\$/\\\$/g;#210820added 本应210820添加，结果后来发现忘了，210911才补上
			s/\"/\\\"/g;
			s/\~/\\\~/g;
			s/\#/\\\#/g;
			$o2=$s2[$bb2]."sum ".$_;
			print$o2,"     (",($aa2+1),"/",scalar(@l2),").."or die$!;
			$r2=readpipe$o2 or die$!;
			$r2=~s/\n//g;
			$r2=~s/\r//g;
			$_=$r2;
			@ss2=split;
			print$ss2[0],"\n";
			#$nn2{$l2[$aa2]}.="\t".$s2[$bb2]."\t".$ss2[0];
			print F2 "\t".$s2[$bb2]."\t".$ss2[0]or die$!;
		}
		#$nn2{$l2[$aa2]}.="\n\n";
		print F2 "\n\n";
	}
}

#open F2,">>".$ARGV[@ARGV-1]or die$!;
#for$aa2(0..@l2-1){
#	print F2 $l2[$aa2].$nn2{$l2[$aa2]}or die$!;
#}
close F2 or die$!;
print"done.\n";
